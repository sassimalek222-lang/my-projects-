<?php

use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\Exception;

require 'PHPMailer/src/Exception.php';
require 'PHPMailer/src/PHPMailer.php';
require 'PHPMailer/src/SMTP.php';

$conn = mysqli_connect("localhost","root","","medrdv");

if(!$conn){
    die("Connexion échouée");
}

$nom = $_POST['nom'];
$email = $_POST['email'];
$password = $_POST['password'];

$sql = "INSERT INTO patients(nom,email,password) VALUES('$nom','$email','$password')";

if(mysqli_query($conn,$sql)){

    $mail = new PHPMailer(true);

    try {

        $mail->isSMTP();
        $mail->Host = 'smtp.gmail.com';
        $mail->SMTPAuth = true;
        $mail->Username = 'eyaarfaoui45@gmail.com';
        $mail->Password = 'tigk ayaf hruw hfnj';
        $mail->SMTPSecure = 'tls';
        $mail->Port = 587;

        $mail->setFrom('eyaarfaoui45@gmail.com', 'medrdv');
        $mail->addAddress($email, $nom);

        $mail->isHTML(true);
        $mail->Subject = 'Verification de votre compte';
        $mail->Body = "Bonjour $nom,<br>Votre compte a été créé.";

        $mail->send();

        echo "Compte créé et email envoyé";

    } catch (Exception $e) {

        echo "Compte créé mais email non envoyé : {$mail->ErrorInfo}";

    }

}else{

    echo "Erreur : ".mysqli_error($conn);

}

?>